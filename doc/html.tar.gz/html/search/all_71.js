var searchData=
[
  ['query',['Query',['../classWeb__Connector.html#aede9f43c28a31f6451cbee7791d62110',1,'Web_Connector']]]
];
