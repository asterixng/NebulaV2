var searchData=
[
  ['plugin_5fresource',['Plugin_Resource',['../classPlugin__Resource.html',1,'']]]
];
